package tennis;

public class Player {
	
	private String name;
	public boolean Toss = false;
	public boolean advantage = false;
	public int point;
	public int roundsWin = 0;
	public int setsWin = 0;
	public int gamesWin = 0;


	public Player(String name)
	{
		this.name = name;
	}

	public String getname()
	{
		return this.name;
	}

	public void incrementRoundsWin()
	{
		roundsWin++;
	}

	public void incrementSetsWin()
	{
		setsWin++;
	}

	public void incrementGameWin()
	{
		this.gamesWin++;
	}
	
	public void incrementPoints(int score)
	{
		this.point = score;
	}

	
	@Override
	public String toString() {
		return String.format("%s    %s   %s   %s", name, setsWin, gamesWin, point);
	}
}