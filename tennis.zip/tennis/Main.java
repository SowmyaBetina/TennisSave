package tennis;

public class Main {
	static Player p1 = new Player("Fedrer");
	static Player p2 = new Player("roger");
	//static Set s = new Set();
	public static void main(String Args[])
	{
		
		Set.playSets(p1 , p2);
		Set.playSets(p1 , p2);
		Set.playSets(p1 , p2);
		Set.playSets(p1 , p2);
		Set.playSets(p1 , p2);
		
		//s.matches();


	}
	

}