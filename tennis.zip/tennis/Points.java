package tennis;
public class Points {
    
    static int gamepoints1;
    static int gamepoints2;
    static int roundponts1;
    static int roundponts2;

    

}
