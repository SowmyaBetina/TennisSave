package tennis;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Round {
	
	public static boolean deuce = false;
	
	static int points[] = {0 , 15 , 30 , 40 , 50};
	static int p1 = 0;
	static int p2 = 0;
	
	static List<Integer> currentRoundScore;
    static Random random = new Random();

	static Player player1 , player2;
	
	public static List<Integer> playRound(Player temp1 , Player temp2)
	{
		currentRoundScore=new ArrayList<>();		
		player1 = temp1;
		player2 = temp2;

		while(p1 !=4 && p2 !=4 && points[p1] - points[p2] != 20 && points[p2] - points[p1] != 20)
		{
		
			score();
			if(p1 == 3 && p2 == 3)
			{
				reset();
			}
			JdbcConnection.save(player1, player2);
			System.out.println( print1());
			System.out.println(print2());
			
		}
		currentRoundScore.add(p1);
		currentRoundScore.add(p2);
		p1 = 0;
		p2 = 0;

		player1.incrementPoints(points[0]);
		player2.incrementPoints(points[0]);
		deuce = false;
		


		return currentRoundScore;
	}

	public static String print1() {
		return (player1.toString());
		
		
	}
	public static String print2() {
		return (player2.toString());
		
		
	}
	private static void reset() {
		
				p1 = 2;
				p2 = 2;
				player1.incrementPoints(points[p1]);
				player2.incrementPoints(points[p2]);
				player1.advantage = false;
				player2.advantage = false;
				deuce = true;
				
		
	}


	public static void score ()
	{
		
//		Scanner scanner = new Scanner(System.in);	
//		int result = scanner.nextInt();
		 Random random = new Random();

		 int result = random.nextInt(2);
		if(result == 0)
		{
			p1++;
			player1.incrementPoints(points[p1]);
			if(deuce == true)
			{
				player1.advantage=true;
			}
		}
		else
		{
			p2++;
			player2.incrementPoints(points[p2]);
			if(deuce == true)
			{
				player2.advantage=true;
			}
		}
		
	
	}
}