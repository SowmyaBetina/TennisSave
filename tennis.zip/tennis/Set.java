package tennis;

public class Set {
	private static int i = 1;
    
    public static void playSets(Player p1 , Player p2)
    {
        

            Game.startGame(p1 , p2);
            //System.out.println("round number " + i);
            i = i+1;
//            System.out.println("round number " + i);
            System.out.println("\nrounds won by  player 1 " + p1.gamesWin);
            System.out.println("\nrounds won by player 2 " + p2.gamesWin);

            if(p1.gamesWin == 6)
            {
                p1.incrementSetsWin();
                p1.gamesWin = 0;

            }
            else
            {
                p2.incrementSetsWin();
                p2.gamesWin = 0;

            }
       
    }
    public void matches() {
    	System.out.println("matchid is "+ i);
    }

}
