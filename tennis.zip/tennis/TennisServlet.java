package com.learning.hello;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import tennis.Game;
import tennis.Main;
import tennis.Player;
import tennis.Round;
import tennis.Set;

import java.io.IOException;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.WebApplicationTemplateResolver;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import Controller.CardContoller;
import Controller.OdometerControllerpackage;
import Controller.TennisController;

@WebServlet("/tennis")

public class TennisServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private TemplateEngine templateEngine;
    private JakartaServletWebApplication application;
	private Main main;
	private Round round;
	static Player p1 = new Player("Fedrer");
	static Player p2 = new Player("roger");


    @Override
    public void init() throws ServletException {
        super.init();
        application = JakartaServletWebApplication.buildApplication(getServletContext());
        final WebApplicationTemplateResolver templateResolver = new WebApplicationTemplateResolver(application);
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateResolver.setPrefix("/WEB-INF/Templates/");
        templateResolver.setSuffix(".html");
        templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);
        
        main = new Main();

    }
    
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		 	var out = res.getWriter();
	        
	        
	  	    final IWebExchange webExchange = this.application.buildExchange(req, res);
	  	    final WebContext ctx = new WebContext(webExchange);
	 	 

	  	    templateEngine.process("Tennisweb", ctx, out);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		  var out = res.getWriter();
		    final IWebExchange webExchange = 
		    this.application.buildExchange(req, res);
		    final WebContext ctx = new WebContext(webExchange);

			//System.out.print(Round.print());
		String button = req.getParameter("button");

		if (button.equals("play"))
	     {
		    Set.playSets(p1, p2);
		    ctx.setVariable("set1", p1.setsWin); 
		    ctx.setVariable("set2", p2.setsWin); 
		    ctx.setVariable("game1", p1.gamesWin); 
		    ctx.setVariable("game2", p2.gamesWin); 
			 ctx.setVariable("round1", p1.point); 
			 ctx.setVariable("round2", p2.point);
	     }
		
	    templateEngine.process("Tennisweb", ctx, out);

	}

}
