package tennis;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class JdbcConnection {
	
	public static void save(Player player1, Player player2)
	{
		 Connection cnx = null;
	   	 PreparedStatement stmt = null;
	   	 	
	   	 try {
	   		 Class.forName("com.mysql.jdbc.Driver"); 
	   		 String insert ="insert into score ( name, setsWin, gamesWin, points) values(?,?,?,?)";
	   		 cnx=DriverManager.getConnection("jdbc:mysql://localhost:3306/scores","sowmyab","sowmyab");
	   		 System.out.println("hello");
	   		 stmt= cnx.prepareStatement(insert);
	   		 stmt.setString(1, player1.getname() );
			 stmt.setInt(2, player1.setsWin);
			 stmt.setInt(3, player1.gamesWin);
			 stmt.setInt(4, player1.point);
	   		 stmt.executeUpdate();
	   		 
	   		 stmt.setString(1, player2.getname() );
			 stmt.setInt(2, player2.setsWin);
			 stmt.setInt(3, player2.gamesWin);
			 stmt.setInt(4, player2.point);
	   		 stmt.executeUpdate();
	   		 
	   		 //insert ="insert into scores ( name, setsWin, gamesWin, point)) values(?,?,?,?)";
	   		 //System.out.println("hello");
	   		 //stmt= cnx.prepareStatement(insert);
	   		 //stmt.setString(1, player2.getname() );
			 //stmt.setInt(2, player2.setsWin);
			 //stmt.setInt(3, player2.gamesWin);
		 	 //stmt.setInt(3, player2.point);
	   		 stmt.executeUpdate();
	   		 stmt.close();
			 cnx.close();
	   	}
	   	 catch(Exception e) {
	   		 e.printStackTrace();
	   	 }
			
	}
	
}